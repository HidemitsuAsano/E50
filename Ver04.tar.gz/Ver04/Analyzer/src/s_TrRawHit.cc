/*
  s_TrRawHit.cc

  2016/2  K.Shirotori
*/

#include "s_TrRawHit.hh"
