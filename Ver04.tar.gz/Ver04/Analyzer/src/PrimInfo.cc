/*
 PrimInfo.cc

 2016/2  K.Shirotori
*/

#include "PrimInfo.hh"




