/*
  JAMData.cc

  2012/10  K.Shirotori
*/

#include "JAMData.hh"




